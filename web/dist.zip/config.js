window.WINDOWS_CONFIG = {
  baseUrl:"http://192.168.1.171:5500",
}